# T58 Print V1
Upload the contents of this folder to a GitHub repository (including hidden .github). Open Actions > Build APK > Run workflow, or push a commit. Download T58-Print-APK artifact, unzip and install app-debug.apk on Android. No paid print service required.

Pair T58 in Android Bluetooth settings, enable permissions, select Classic Bluetooth and choose printer. Try Test print. If necessary select BLE and scan. BLE characteristic selection is experimental and may need printer-specific UUIDs. The app uses ESC/POS GS v 0 raster graphics, 203 DPI assumed. Width defaults to 45 mm (360 dots), height 0 automatically fits content. Fixed height rejects oversized text; images fit proportionally. Continuous paper only; no gap sensor calibration. Feed paper manually if needed. Preview then Print. No internet permission.

Source is provided unbuilt and not tested on actual hardware. GitHub Actions compiles a debug APK; check build logs if errors occur.
